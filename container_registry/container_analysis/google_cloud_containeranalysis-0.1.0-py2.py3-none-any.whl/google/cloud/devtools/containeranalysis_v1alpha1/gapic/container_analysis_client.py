# Copyright 2017 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Accesses the google.devtools.containeranalysis.v1alpha1 ContainerAnalysis API."""

import functools
import pkg_resources

import google.api_core.gapic_v1.client_info
import google.api_core.gapic_v1.config
import google.api_core.gapic_v1.method
import google.api_core.grpc_helpers
import google.api_core.page_iterator
import google.api_core.path_template

from google.cloud.devtools.containeranalysis_v1alpha1.gapic import container_analysis_client_config
from google.cloud.devtools.containeranalysis_v1alpha1.gapic import enums
from google.cloud.devtools.containeranalysis_v1alpha1.proto import containeranalysis_pb2
from google.iam.v1 import iam_policy_pb2
from google.iam.v1 import policy_pb2
from google.protobuf import field_mask_pb2

_GAPIC_LIBRARY_VERSION = pkg_resources.get_distribution(
    'google-cloud-containeranalysis', ).version


class ContainerAnalysisClient(object):
    """
    Retrieves the results of vulnerability scanning of cloud components such as
    container images. The Container Analysis API is an implementation of the
    `Grafeas <https://cloud.google.comgrafeas.io>`_ API.

    The vulnerability results are stored as a series of Occurrences.
    An ``Occurrence`` contains information about a specific vulnerability in a
    resource. An ``Occurrence`` references a ``Note``. A ``Note`` contains details
    about the vulnerability and is stored in a stored in a separate project.
    Multiple ``Occurrences`` can reference the same ``Note``. For example, an SSL
    vulnerability could affect multiple packages in an image. In this case,
    there would be one ``Note`` for the vulnerability and an ``Occurrence`` for
    each package with the vulnerability referencing that ``Note``.
    """

    SERVICE_ADDRESS = 'containeranalysis.googleapis.com:443'
    """The default address of the service."""

    # The scopes needed to make gRPC calls to all of the methods defined in
    # this service
    _DEFAULT_SCOPES = ('https://www.googleapis.com/auth/cloud-platform', )

    # The name of the interface for this client. This is the key used to find
    # method configuration in the client_config dictionary.
    _INTERFACE_NAME = 'google.devtools.containeranalysis.v1alpha1.ContainerAnalysis'

    @classmethod
    def project_path(cls, project):
        """Return a fully-qualified project string."""
        return google.api_core.path_template.expand(
            'projects/{project}',
            project=project,
        )

    @classmethod
    def note_path(cls, project, note):
        """Return a fully-qualified note string."""
        return google.api_core.path_template.expand(
            'projects/{project}/notes/{note}',
            project=project,
            note=note,
        )

    @classmethod
    def occurrence_path(cls, project, occurrence):
        """Return a fully-qualified occurrence string."""
        return google.api_core.path_template.expand(
            'projects/{project}/occurrences/{occurrence}',
            project=project,
            occurrence=occurrence,
        )

    def __init__(self,
                 channel=None,
                 credentials=None,
                 client_config=container_analysis_client_config.config,
                 client_info=None):
        """Constructor.

        Args:
            channel (grpc.Channel): A ``Channel`` instance through
                which to make calls. This argument is mutually exclusive
                with ``credentials``; providing both will raise an exception.
            credentials (google.auth.credentials.Credentials): The
                authorization credentials to attach to requests. These
                credentials identify this application to the service. If none
                are specified, the client will attempt to ascertain the
                credentials from the environment.
            client_config (dict): A dictionary of call options for each
                method. If not specified, the default configuration is used.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you're developing
                your own client library.
        """
        # If both `channel` and `credentials` are specified, raise an
        # exception (channels come with credentials baked in already).
        if channel is not None and credentials is not None:
            raise ValueError(
                'The `channel` and `credentials` arguments to {} are mutually '
                'exclusive.'.format(self.__class__.__name__), )

        # Create the channel.
        if channel is None:
            channel = google.api_core.grpc_helpers.create_channel(
                self.SERVICE_ADDRESS,
                credentials=credentials,
                scopes=self._DEFAULT_SCOPES,
            )

        # Create the gRPC stubs.
        self.container_analysis_stub = (
            containeranalysis_pb2.ContainerAnalysisStub(channel))

        if client_info is None:
            client_info = (
                google.api_core.gapic_v1.client_info.DEFAULT_CLIENT_INFO)
        client_info.gapic_version = _GAPIC_LIBRARY_VERSION

        # Parse out the default settings for retry and timeout for each RPC
        # from the client configuration.
        # (Ordinarily, these are the defaults specified in the `*_config.py`
        # file next to this one.)
        method_configs = google.api_core.gapic_v1.config.parse_method_configs(
            client_config['interfaces'][self._INTERFACE_NAME], )

        # Write the "inner API call" methods to the class.
        # These are wrapped versions of the gRPC stub methods, with retry and
        # timeout configuration applied, called by the public methods on
        # this class.
        self._get_occurrence = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.GetOccurrence,
            default_retry=method_configs['GetOccurrence'].retry,
            default_timeout=method_configs['GetOccurrence'].timeout,
            client_info=client_info,
        )
        self._list_occurrences = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.ListOccurrences,
            default_retry=method_configs['ListOccurrences'].retry,
            default_timeout=method_configs['ListOccurrences'].timeout,
            client_info=client_info,
        )
        self._delete_occurrence = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.DeleteOccurrence,
            default_retry=method_configs['DeleteOccurrence'].retry,
            default_timeout=method_configs['DeleteOccurrence'].timeout,
            client_info=client_info,
        )
        self._create_occurrence = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.CreateOccurrence,
            default_retry=method_configs['CreateOccurrence'].retry,
            default_timeout=method_configs['CreateOccurrence'].timeout,
            client_info=client_info,
        )
        self._update_occurrence = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.UpdateOccurrence,
            default_retry=method_configs['UpdateOccurrence'].retry,
            default_timeout=method_configs['UpdateOccurrence'].timeout,
            client_info=client_info,
        )
        self._get_occurrence_note = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.GetOccurrenceNote,
            default_retry=method_configs['GetOccurrenceNote'].retry,
            default_timeout=method_configs['GetOccurrenceNote'].timeout,
            client_info=client_info,
        )
        self._get_note = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.GetNote,
            default_retry=method_configs['GetNote'].retry,
            default_timeout=method_configs['GetNote'].timeout,
            client_info=client_info,
        )
        self._list_notes = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.ListNotes,
            default_retry=method_configs['ListNotes'].retry,
            default_timeout=method_configs['ListNotes'].timeout,
            client_info=client_info,
        )
        self._delete_note = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.DeleteNote,
            default_retry=method_configs['DeleteNote'].retry,
            default_timeout=method_configs['DeleteNote'].timeout,
            client_info=client_info,
        )
        self._create_note = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.CreateNote,
            default_retry=method_configs['CreateNote'].retry,
            default_timeout=method_configs['CreateNote'].timeout,
            client_info=client_info,
        )
        self._update_note = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.UpdateNote,
            default_retry=method_configs['UpdateNote'].retry,
            default_timeout=method_configs['UpdateNote'].timeout,
            client_info=client_info,
        )
        self._list_note_occurrences = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.ListNoteOccurrences,
            default_retry=method_configs['ListNoteOccurrences'].retry,
            default_timeout=method_configs['ListNoteOccurrences'].timeout,
            client_info=client_info,
        )
        self._get_vulnz_occurrences_summary = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.GetVulnzOccurrencesSummary,
            default_retry=method_configs['GetVulnzOccurrencesSummary'].retry,
            default_timeout=method_configs['GetVulnzOccurrencesSummary']
            .timeout,
            client_info=client_info,
        )
        self._set_iam_policy = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.SetIamPolicy,
            default_retry=method_configs['SetIamPolicy'].retry,
            default_timeout=method_configs['SetIamPolicy'].timeout,
            client_info=client_info,
        )
        self._get_iam_policy = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.GetIamPolicy,
            default_retry=method_configs['GetIamPolicy'].retry,
            default_timeout=method_configs['GetIamPolicy'].timeout,
            client_info=client_info,
        )
        self._test_iam_permissions = google.api_core.gapic_v1.method.wrap_method(
            self.container_analysis_stub.TestIamPermissions,
            default_retry=method_configs['TestIamPermissions'].retry,
            default_timeout=method_configs['TestIamPermissions'].timeout,
            client_info=client_info,
        )

    # Service calls
    def get_occurrence(self,
                       name,
                       retry=google.api_core.gapic_v1.method.DEFAULT,
                       timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Returns the requested ``Occurrence``.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> name = client.occurrence_path('[PROJECT]', '[OCCURRENCE]')
            >>>
            >>> response = client.get_occurrence(name)

        Args:
            name (str): The name of the occurrence of the form
                \"projects/{project_id}/occurrences/{OCCURRENCE_ID}\"
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Occurrence` instance.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.GetOccurrenceRequest(name=name, )
        return self._get_occurrence(request, retry=retry, timeout=timeout)

    def list_occurrences(self,
                         parent,
                         name=None,
                         filter_=None,
                         page_size=None,
                         retry=google.api_core.gapic_v1.method.DEFAULT,
                         timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Lists active ``Occurrences`` for a given project matching the filters.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> parent = client.project_path('[PROJECT]')
            >>>
            >>>
            >>> # Iterate over all results
            >>> for element in client.list_occurrences(parent):
            ...     # process element
            ...     pass
            >>>
            >>> # Or iterate over results one page at a time
            >>> for page in client.list_occurrences(parent, options=CallOptions(page_token=INITIAL_PAGE)):
            ...     for element in page:
            ...         # process element
            ...         pass

        Args:
            parent (str): This contains the project Id for example: projects/{project_id}.
            name (str): The name field contains the project Id. For example:
                \"projects/{project_id}
                @Deprecated
            filter_ (str): The filter expression.
            page_size (int): The maximum number of resources contained in the
                underlying API response. If page streaming is performed per-
                resource, this parameter does not affect the return value. If page
                streaming is performed per-page, this determines the maximum number
                of resources in a page.
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.gax.PageIterator` instance. By default, this
            is an iterable of :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Occurrence` instances.
            This object can also be configured to iterate over the pages
            of the response through the `options` parameter.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.ListOccurrencesRequest(
            parent=parent,
            name=name,
            filter=filter_,
            page_size=page_size,
        )
        iterator = google.api_core.page_iterator.GRPCIterator(
            client=None,
            method=functools.partial(
                self._list_occurrences, retry=retry, timeout=timeout),
            request=request,
            items_field='occurrences',
            request_token_field='page_token',
            response_token_field='next_page_token',
        )
        return iterator

    def delete_occurrence(self,
                          name,
                          retry=google.api_core.gapic_v1.method.DEFAULT,
                          timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Deletes the given ``Occurrence`` from the system. Use this when
        an ``Occurrence`` is no longer applicable for the given resource.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> name = client.occurrence_path('[PROJECT]', '[OCCURRENCE]')
            >>>
            >>> client.delete_occurrence(name)

        Args:
            name (str): The name of the occurrence in the form of
                \"projects/{project_id}/occurrences/{OCCURRENCE_ID}\"
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.DeleteOccurrenceRequest(name=name, )
        self._delete_occurrence(request, retry=retry, timeout=timeout)

    def create_occurrence(self,
                          parent,
                          occurrence,
                          name=None,
                          retry=google.api_core.gapic_v1.method.DEFAULT,
                          timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Creates a new ``Occurrence``. Use this method to create ``Occurrences``
        for a resource.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> parent = client.project_path('[PROJECT]')
            >>> occurrence = {}
            >>>
            >>> response = client.create_occurrence(parent, occurrence)

        Args:
            parent (str): This field contains the project Id for example: \"projects/{project_id}\"
            occurrence (Union[dict, ~google.cloud.devtools.containeranalysis_v1alpha1.types.Occurrence]): The occurrence to be inserted
                If a dict is provided, it must be of the same form as the protobuf
                message :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Occurrence`
            name (str): The name of the project.  Should be of the form \"projects/{project_id}\".
                @Deprecated
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Occurrence` instance.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.CreateOccurrenceRequest(
            parent=parent,
            occurrence=occurrence,
            name=name,
        )
        return self._create_occurrence(request, retry=retry, timeout=timeout)

    def update_occurrence(self,
                          name,
                          occurrence,
                          update_mask=None,
                          retry=google.api_core.gapic_v1.method.DEFAULT,
                          timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Updates an existing occurrence.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> name = client.occurrence_path('[PROJECT]', '[OCCURRENCE]')
            >>> occurrence = {}
            >>>
            >>> response = client.update_occurrence(name, occurrence)

        Args:
            name (str): The name of the occurrence.
                Should be of the form \"projects/{project_id}/occurrences/{OCCURRENCE_ID}\".
            occurrence (Union[dict, ~google.cloud.devtools.containeranalysis_v1alpha1.types.Occurrence]): The updated occurrence.
                If a dict is provided, it must be of the same form as the protobuf
                message :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Occurrence`
            update_mask (Union[dict, ~google.cloud.devtools.containeranalysis_v1alpha1.types.FieldMask]): The fields to update.
                If a dict is provided, it must be of the same form as the protobuf
                message :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.FieldMask`
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Occurrence` instance.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.UpdateOccurrenceRequest(
            name=name,
            occurrence=occurrence,
            update_mask=update_mask,
        )
        return self._update_occurrence(request, retry=retry, timeout=timeout)

    def get_occurrence_note(self,
                            name,
                            retry=google.api_core.gapic_v1.method.DEFAULT,
                            timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Gets the ``Note`` attached to the given ``Occurrence``.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> name = client.occurrence_path('[PROJECT]', '[OCCURRENCE]')
            >>>
            >>> response = client.get_occurrence_note(name)

        Args:
            name (str): The name of the occurrence in the form
                \"projects/{project_id}/occurrences/{OCCURRENCE_ID}\"
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Note` instance.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.GetOccurrenceNoteRequest(name=name, )
        return self._get_occurrence_note(request, retry=retry, timeout=timeout)

    def get_note(self,
                 name,
                 retry=google.api_core.gapic_v1.method.DEFAULT,
                 timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Returns the requested ``Note``.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> name = client.note_path('[PROJECT]', '[NOTE]')
            >>>
            >>> response = client.get_note(name)

        Args:
            name (str): The name of the note in the form of
                \"providers/{provider_id}/notes/{NOTE_ID}\"
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Note` instance.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.GetNoteRequest(name=name, )
        return self._get_note(request, retry=retry, timeout=timeout)

    def list_notes(self,
                   parent,
                   name=None,
                   filter_=None,
                   page_size=None,
                   retry=google.api_core.gapic_v1.method.DEFAULT,
                   timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Lists all ``Notes`` for a given project.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> parent = client.project_path('[PROJECT]')
            >>>
            >>>
            >>> # Iterate over all results
            >>> for element in client.list_notes(parent):
            ...     # process element
            ...     pass
            >>>
            >>> # Or iterate over results one page at a time
            >>> for page in client.list_notes(parent, options=CallOptions(page_token=INITIAL_PAGE)):
            ...     for element in page:
            ...         # process element
            ...         pass

        Args:
            parent (str): This field contains the project Id for example:
                \"project/{project_id}
            name (str): The name field will contain the project Id for example:
                \"providers/{provider_id}
                @Deprecated
            filter_ (str): The filter expression.
            page_size (int): The maximum number of resources contained in the
                underlying API response. If page streaming is performed per-
                resource, this parameter does not affect the return value. If page
                streaming is performed per-page, this determines the maximum number
                of resources in a page.
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.gax.PageIterator` instance. By default, this
            is an iterable of :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Note` instances.
            This object can also be configured to iterate over the pages
            of the response through the `options` parameter.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.ListNotesRequest(
            parent=parent,
            name=name,
            filter=filter_,
            page_size=page_size,
        )
        iterator = google.api_core.page_iterator.GRPCIterator(
            client=None,
            method=functools.partial(
                self._list_notes, retry=retry, timeout=timeout),
            request=request,
            items_field='notes',
            request_token_field='page_token',
            response_token_field='next_page_token',
        )
        return iterator

    def delete_note(self,
                    name,
                    retry=google.api_core.gapic_v1.method.DEFAULT,
                    timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Deletes the given ``Note`` from the system.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> name = client.note_path('[PROJECT]', '[NOTE]')
            >>>
            >>> client.delete_note(name)

        Args:
            name (str): The name of the note in the form of
                \"providers/{provider_id}/notes/{NOTE_ID}\"
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.DeleteNoteRequest(name=name, )
        self._delete_note(request, retry=retry, timeout=timeout)

    def create_note(self,
                    parent,
                    note_id,
                    note,
                    name=None,
                    retry=google.api_core.gapic_v1.method.DEFAULT,
                    timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Creates a new ``Note``.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> parent = client.project_path('[PROJECT]')
            >>> note_id = ''
            >>> note = {}
            >>>
            >>> response = client.create_note(parent, note_id, note)

        Args:
            parent (str): This field contains the project Id for example:
                \"project/{project_id}
            note_id (str): The ID to use for this note.
            note (Union[dict, ~google.cloud.devtools.containeranalysis_v1alpha1.types.Note]): The Note to be inserted
                If a dict is provided, it must be of the same form as the protobuf
                message :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Note`
            name (str): The name of the project.
                Should be of the form \"providers/{provider_id}\".
                @Deprecated
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Note` instance.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.CreateNoteRequest(
            parent=parent,
            note_id=note_id,
            note=note,
            name=name,
        )
        return self._create_note(request, retry=retry, timeout=timeout)

    def update_note(self,
                    name,
                    note,
                    update_mask=None,
                    retry=google.api_core.gapic_v1.method.DEFAULT,
                    timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Updates an existing ``Note``.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> name = client.note_path('[PROJECT]', '[NOTE]')
            >>> note = {}
            >>>
            >>> response = client.update_note(name, note)

        Args:
            name (str): The name of the note.
                Should be of the form \"projects/{provider_id}/notes/{note_id}\".
            note (Union[dict, ~google.cloud.devtools.containeranalysis_v1alpha1.types.Note]): The updated note.
                If a dict is provided, it must be of the same form as the protobuf
                message :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Note`
            update_mask (Union[dict, ~google.cloud.devtools.containeranalysis_v1alpha1.types.FieldMask]): The fields to update.
                If a dict is provided, it must be of the same form as the protobuf
                message :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.FieldMask`
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Note` instance.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.UpdateNoteRequest(
            name=name,
            note=note,
            update_mask=update_mask,
        )
        return self._update_note(request, retry=retry, timeout=timeout)

    def list_note_occurrences(self,
                              name,
                              filter_=None,
                              page_size=None,
                              retry=google.api_core.gapic_v1.method.DEFAULT,
                              timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Lists ``Occurrences`` referencing the specified ``Note``. Use this method to
        get all occurrences referencing your ``Note`` across all your customer
        projects.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> name = client.note_path('[PROJECT]', '[NOTE]')
            >>>
            >>>
            >>> # Iterate over all results
            >>> for element in client.list_note_occurrences(name):
            ...     # process element
            ...     pass
            >>>
            >>> # Or iterate over results one page at a time
            >>> for page in client.list_note_occurrences(name, options=CallOptions(page_token=INITIAL_PAGE)):
            ...     for element in page:
            ...         # process element
            ...         pass

        Args:
            name (str): The name field will contain the note name for example:
                  \"provider/{provider_id}/notes/{note_id}\"
            filter_ (str): The filter expression.
            page_size (int): The maximum number of resources contained in the
                underlying API response. If page streaming is performed per-
                resource, this parameter does not affect the return value. If page
                streaming is performed per-page, this determines the maximum number
                of resources in a page.
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.gax.PageIterator` instance. By default, this
            is an iterable of :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Occurrence` instances.
            This object can also be configured to iterate over the pages
            of the response through the `options` parameter.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.ListNoteOccurrencesRequest(
            name=name,
            filter=filter_,
            page_size=page_size,
        )
        iterator = google.api_core.page_iterator.GRPCIterator(
            client=None,
            method=functools.partial(
                self._list_note_occurrences, retry=retry, timeout=timeout),
            request=request,
            items_field='occurrences',
            request_token_field='page_token',
            response_token_field='next_page_token',
        )
        return iterator

    def get_vulnz_occurrences_summary(
            self,
            parent,
            filter_=None,
            retry=google.api_core.gapic_v1.method.DEFAULT,
            timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Gets a summary of the number and severity of occurrences.

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> parent = client.project_path('[PROJECT]')
            >>>
            >>> response = client.get_vulnz_occurrences_summary(parent)

        Args:
            parent (str): This contains the project Id for example: projects/{project_id}
            filter_ (str): The filter expression.
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.GetVulnzOccurrencesSummaryResponse` instance.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = containeranalysis_pb2.GetVulnzOccurrencesSummaryRequest(
            parent=parent,
            filter=filter_,
        )
        return self._get_vulnz_occurrences_summary(
            request, retry=retry, timeout=timeout)

    def set_iam_policy(self,
                       resource,
                       policy,
                       retry=google.api_core.gapic_v1.method.DEFAULT,
                       timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Sets the access control policy on the specified ``Note`` or ``Occurrence``.
        Requires ``containeranalysis.notes.setIamPolicy`` or
        ``containeranalysis.occurrences.setIamPolicy`` permission if the resource is
        a ``Note`` or an ``Occurrence``, respectively.
        Attempting to call this method without these permissions will result in a ``
        ``PERMISSION_DENIED`` error.
        Attempting to call this method on a non-existent resource will result in a
        ``NOT_FOUND`` error if the user has ``containeranalysis.notes.list`` permission
        on a ``Note`` or ``containeranalysis.occurrences.list`` on an ``Occurrence``, or
        a ``PERMISSION_DENIED`` error otherwise. The resource takes the following
        formats: ``projects/{projectid}/occurrences/{occurrenceid}`` for occurrences
        and projects/{projectid}/notes/{noteid} for notes

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> resource = client.note_path('[PROJECT]', '[NOTE]')
            >>> policy = {}
            >>>
            >>> response = client.set_iam_policy(resource, policy)

        Args:
            resource (str): REQUIRED: The resource for which the policy is being specified.
                ``resource`` is usually specified as a path. For example, a Project
                resource is specified as ``projects/{project}``.
            policy (Union[dict, ~google.cloud.devtools.containeranalysis_v1alpha1.types.Policy]): REQUIRED: The complete policy to be applied to the ``resource``. The size of
                the policy is limited to a few 10s of KB. An empty policy is a
                valid policy but certain Cloud Platform services (such as Projects)
                might reject them.
                If a dict is provided, it must be of the same form as the protobuf
                message :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Policy`
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Policy` instance.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = iam_policy_pb2.SetIamPolicyRequest(
            resource=resource,
            policy=policy,
        )
        return self._set_iam_policy(request, retry=retry, timeout=timeout)

    def get_iam_policy(self,
                       resource,
                       retry=google.api_core.gapic_v1.method.DEFAULT,
                       timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Gets the access control policy for a note or an ``Occurrence`` resource.
        Requires ``containeranalysis.notes.setIamPolicy`` or
        ``containeranalysis.occurrences.setIamPolicy`` permission if the resource is
        a note or occurrence, respectively.
        Attempting to call this method on a resource without the required
        permission will result in a ``PERMISSION_DENIED`` error. Attempting to call
        this method on a non-existent resource will result in a ``NOT_FOUND`` error
        if the user has list permission on the project, or a ``PERMISSION_DENIED``
        error otherwise. The resource takes the following formats:
        ``projects/{PROJECT_ID}/occurrences/{OCCURRENCE_ID}`` for occurrences and
        projects/{PROJECT_ID}/notes/{NOTE_ID} for notes

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> resource = client.note_path('[PROJECT]', '[NOTE]')
            >>>
            >>> response = client.get_iam_policy(resource)

        Args:
            resource (str): REQUIRED: The resource for which the policy is being requested.
                ``resource`` is usually specified as a path. For example, a Project
                resource is specified as ``projects/{project}``.
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.Policy` instance.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = iam_policy_pb2.GetIamPolicyRequest(resource=resource, )
        return self._get_iam_policy(request, retry=retry, timeout=timeout)

    def test_iam_permissions(self,
                             resource,
                             permissions,
                             retry=google.api_core.gapic_v1.method.DEFAULT,
                             timeout=google.api_core.gapic_v1.method.DEFAULT):
        """
        Returns the permissions that a caller has on the specified note or
        occurrence resource. Requires list permission on the project (for example,
        \"storage.objects.list\" on the containing bucket for testing permission of
        an object). Attempting to call this method on a non-existent resource will
        result in a ``NOT_FOUND`` error if the user has list permission on the
        project, or a ``PERMISSION_DENIED`` error otherwise. The resource takes the
        following formats: ``projects/{PROJECT_ID}/occurrences/{OCCURRENCE_ID}`` for
        ``Occurrences`` and ``projects/{PROJECT_ID}/notes/{NOTE_ID}`` for ``Notes``

        Example:
            >>> from google.cloud.devtools import containeranalysis_v1alpha1
            >>>
            >>> client = containeranalysis_v1alpha1.ContainerAnalysisClient()
            >>>
            >>> resource = client.note_path('[PROJECT]', '[NOTE]')
            >>> permissions = []
            >>>
            >>> response = client.test_iam_permissions(resource, permissions)

        Args:
            resource (str): REQUIRED: The resource for which the policy detail is being requested.
                ``resource`` is usually specified as a path. For example, a Project
                resource is specified as ``projects/{project}``.
            permissions (list[str]): The set of permissions to check for the ``resource``. Permissions with
                wildcards (such as '*' or 'storage.*') are not allowed. For more
                information see
                `IAM Overview <https://cloud.google.com/iam/docs/overview#permissions>`_.
            retry (Optional[google.api_core.retry.Retry]):  A retry object used
                to retry requests. If ``None`` is specified, requests will not
                be retried.
            timeout (Optional[float]): The amount of time, in seconds, to wait
                for the request to complete. Note that if ``retry`` is
                specified, the timeout applies to each individual attempt.

        Returns:
            A :class:`~google.cloud.devtools.containeranalysis_v1alpha1.types.TestIamPermissionsResponse` instance.

        Raises:
            google.api_core.exceptions.GoogleAPICallError: If the request
                    failed for any reason.
            google.api_core.exceptions.RetryError: If the request failed due
                    to a retryable error and retry attempts failed.
            ValueError: If the parameters are invalid.
        """
        request = iam_policy_pb2.TestIamPermissionsRequest(
            resource=resource,
            permissions=permissions,
        )
        return self._test_iam_permissions(
            request, retry=retry, timeout=timeout)
