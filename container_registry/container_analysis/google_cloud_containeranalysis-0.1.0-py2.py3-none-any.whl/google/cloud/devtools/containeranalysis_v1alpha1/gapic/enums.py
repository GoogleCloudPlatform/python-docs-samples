# Copyright 2017 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Wrappers for protocol buffer enum types."""


class VulnerabilityType(object):
    class Severity(object):
        """
        Note provider-assigned severity/impact ranking

        Attributes:
          SEVERITY_UNSPECIFIED (int): Unknown Impact
          MINIMAL (int): Minimal Impact
          LOW (int): Low Impact
          MEDIUM (int): Medium Impact
          HIGH (int): High Impact
          CRITICAL (int): Critical Impact
        """
        SEVERITY_UNSPECIFIED = 0
        MINIMAL = 1
        LOW = 2
        MEDIUM = 3
        HIGH = 4
        CRITICAL = 5

    class Version(object):
        class VersionKind(object):
            """
            Whether this is an ordinary package version or a
            sentinel MIN/MAX version.

            Attributes:
              NORMAL (int): A standard package version, defined by the other fields.
              MINIMUM (int): A special version representing negative infinity,
              other fields are ignored.
              MAXIMUM (int): A special version representing positive infinity,
              other fields are ignored.
            """
            NORMAL = 0
            MINIMUM = 1
            MAXIMUM = 2


class DockerImage(object):
    class Layer(object):
        class Directive(object):
            """
            Instructions from dockerfile

            Attributes:
              DIRECTIVE_UNSPECIFIED (int): Default value for unsupported/missing directive
              MAINTAINER (int): https://docs.docker.com/reference/builder/#maintainer
              RUN (int): https://docs.docker.com/reference/builder/#run
              CMD (int): https://docs.docker.com/reference/builder/#cmd
              LABEL (int): https://docs.docker.com/reference/builder/#label
              EXPOSE (int): https://docs.docker.com/reference/builder/#expose
              ENV (int): https://docs.docker.com/reference/builder/#env
              ADD (int): https://docs.docker.com/reference/builder/#add
              COPY (int): https://docs.docker.com/reference/builder/#copy
              ENTRYPOINT (int): https://docs.docker.com/reference/builder/#entrypoint
              VOLUME (int): https://docs.docker.com/reference/builder/#volume
              USER (int): https://docs.docker.com/reference/builder/#user
              WORKDIR (int): https://docs.docker.com/reference/builder/#workdir
              ARG (int): https://docs.docker.com/reference/builder/#arg
              ONBUILD (int): https://docs.docker.com/reference/builder/#onbuild
              STOPSIGNAL (int): https://docs.docker.com/reference/builder/#stopsignal
              HEALTHCHECK (int): https://docs.docker.com/reference/builder/#healthcheck
              SHELL (int): https://docs.docker.com/reference/builder/#shell
            """
            DIRECTIVE_UNSPECIFIED = 0
            MAINTAINER = 1
            RUN = 2
            CMD = 3
            LABEL = 4
            EXPOSE = 5
            ENV = 6
            ADD = 7
            COPY = 8
            ENTRYPOINT = 9
            VOLUME = 10
            USER = 11
            WORKDIR = 12
            ARG = 13
            ONBUILD = 14
            STOPSIGNAL = 15
            HEALTHCHECK = 16
            SHELL = 17


class PackageManager(object):
    class Architecture(object):
        """
        Instruction set architectures supported by various package managers.

        Attributes:
          ARCHITECTURE_UNSPECIFIED (int): Unknown architecture
          X86 (int): X86 architecture
          X64 (int): X64 architecture
        """
        ARCHITECTURE_UNSPECIFIED = 0
        X86 = 1
        X64 = 2


class AliasContext(object):
    class Kind(object):
        """
        The type of an alias.

        Attributes:
          KIND_UNSPECIFIED (int): Unknown.
          FIXED (int): Git tag.
          MOVABLE (int): Git branch.
          OTHER (int): Used to specify non-standard aliases. For example, if a Git repo has a
          ref named \"refs/foo/bar\".
        """
        KIND_UNSPECIFIED = 0
        FIXED = 1
        MOVABLE = 2
        OTHER = 4


class Hash(object):
    class HashType(object):
        """
        Specifies the hash algorithm, if any.

        Attributes:
          NONE (int): No hash requested.
          SHA256 (int): A sha256 hash.
        """
        NONE = 0
        SHA256 = 1


class Note(object):
    class Kind(object):
        """
        This must be 1:1 with members of our oneofs, it can be used for filtering
        Note and Occurrence on their kind.

        Attributes:
          KIND_UNSPECIFIED (int): Unknown
          PACKAGE_VULNERABILITY (int): The note and occurrence represent a package vulnerability.
          BUILD_DETAILS (int): The note and occurrence assert build provenance.
          IMAGE_BASIS (int): This represents an image basis relationship.
          PACKAGE_MANAGER (int): This represents a package installed via a package manager.
          DEPLOYABLE (int): The note and occurrence track deployment events.
          DISCOVERY (int): The note and occurrence track the initial discovery status of a resource.
        """
        KIND_UNSPECIFIED = 0
        PACKAGE_VULNERABILITY = 2
        BUILD_DETAILS = 3
        IMAGE_BASIS = 4
        PACKAGE_MANAGER = 5
        DEPLOYABLE = 6
        DISCOVERY = 7


class Deployable(object):
    class Deployment(object):
        class Platform(object):
            """
            Types of platforms.

            Attributes:
              PLATFORM_UNSPECIFIED (int): Unknown
              GKE (int): Google Container Engine
              FLEX (int): Google App Engine: Flexible Environment
              CUSTOM (int): Custom user-defined platform
            """
            PLATFORM_UNSPECIFIED = 0
            GKE = 1
            FLEX = 2
            CUSTOM = 3


class BuildSignature(object):
    class KeyType(object):
        """
        Public key formats

        Attributes:
          KEY_TYPE_UNSPECIFIED (int): ``KeyType`` is not set.
          PGP_ASCII_ARMORED (int): ``PGP ASCII Armored`` public key.
          PKIX_PEM (int): ``PKIX PEM`` public key.
        """
        KEY_TYPE_UNSPECIFIED = 0
        PGP_ASCII_ARMORED = 1
        PKIX_PEM = 2
