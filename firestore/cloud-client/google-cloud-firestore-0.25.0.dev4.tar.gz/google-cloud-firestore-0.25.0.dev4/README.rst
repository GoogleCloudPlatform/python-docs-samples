Python Client for Google Cloud Firestore
========================================

    Python idiomatic client for `Google Cloud Firestore`_

.. _Google Cloud Firestore: https://firebase.google.com/docs/firestore/

Quick Start
-----------

::

    $ pip install --upgrade google-cloud-firestore
