# Copyright 2017, Google Inc. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import absolute_import
import sys

from google.cloud.proto.firestore.v1beta1 import common_pb2
from google.cloud.proto.firestore.v1beta1 import document_pb2
from google.cloud.proto.firestore.v1beta1 import event_flow_document_change_pb2
from google.cloud.proto.firestore.v1beta1 import firestore_admin_pb2
from google.cloud.proto.firestore.v1beta1 import firestore_pb2
from google.cloud.proto.firestore.v1beta1 import index_pb2
from google.cloud.proto.firestore.v1beta1 import query_pb2
from google.cloud.proto.firestore.v1beta1 import write_pb2

from google.gax.utils.messages import get_messages


_MODULES = (
    common_pb2,
    document_pb2,
    event_flow_document_change_pb2,
    firestore_admin_pb2,
    firestore_pb2,
    index_pb2,
    query_pb2,
    write_pb2,
)

_NAMES = []
for _MODULE in _MODULES:
    for _NAME, _MESSAGE in get_messages(_MODULE).items():
        _MESSAGE.__module__ = 'google.cloud.firestore_v1beta1.types'
        setattr(sys.modules[__name__], _NAME, _MESSAGE)
        _NAMES.append(_NAME)


__all__ = tuple(sorted(_NAMES))
