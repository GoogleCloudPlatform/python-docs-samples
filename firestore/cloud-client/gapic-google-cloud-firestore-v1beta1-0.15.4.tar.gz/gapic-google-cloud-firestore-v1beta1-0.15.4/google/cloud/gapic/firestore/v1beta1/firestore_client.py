# Copyright 2017, Google Inc. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# EDITING INSTRUCTIONS
# This file was generated from the file
# https://github.com/google/googleapis/blob/master/google/firestore/v1beta1/firestore.proto,
# and updates to that file get reflected here through a refresh process.
# For the short term, the refresh process will only be runnable by Google engineers.
#
# The only allowed edits are to method and file documentation. A 3-way
# merge preserves those additions if the generated source changes.
"""Accesses the google.firestore.v1beta1 Firestore API."""

import collections
import json
import os
import pkg_resources
import platform

from google.gax import api_callable
from google.gax import config
from google.gax import path_template
from google.gax.utils import oneof
import google.gax

from google.cloud.gapic.firestore.v1beta1 import enums
from google.cloud.proto.firestore.v1beta1 import common_pb2
from google.cloud.proto.firestore.v1beta1 import document_pb2
from google.cloud.proto.firestore.v1beta1 import firestore_pb2
from google.cloud.proto.firestore.v1beta1 import query_pb2
from google.cloud.proto.firestore.v1beta1 import write_pb2
from google.protobuf import timestamp_pb2

_PageDesc = google.gax.PageDescriptor


class FirestoreClient(object):
    """
    The Cloud Firestore service.

    This service exposes several types of comparable timestamps:

    *    ``create_time`` - The time at which a document was created. Changes only
    ::

         when a document is deleted, then re-created. Increases in a strict
          monotonic fashion.
    *    ``update_time`` - The time at which a document was last updated. Changes
    ::

         every time a document is modified. Does not change when a write results
         in no modifications. Increases in a strict monotonic fashion.
    *    ``read_time`` - The time at which a particular state was observed. Used
    ::

         to denote a consistent snapshot of the database or the time at which a
         Document was observed to not exist.
    *    ``commit_time`` - The time at which the writes in a transaction were
    ::

         committed. Any read with an equal or greater `read_time` is guaranteed
         to see the effects of the transaction.
    """

    SERVICE_ADDRESS = 'firestore.googleapis.com'
    """The default address of the service."""

    DEFAULT_SERVICE_PORT = 443
    """The default port of the service."""

    _PAGE_DESCRIPTORS = {
        'list_documents':
        _PageDesc('page_token', 'next_page_token', 'documents'),
        'list_collection_ids':
        _PageDesc('page_token', 'next_page_token', 'collection_ids')
    }

    # The scopes needed to make gRPC calls to all of the methods defined in
    # this service
    _ALL_SCOPES = ('https://www.googleapis.com/auth/cloud-platform',
                   'https://www.googleapis.com/auth/datastore', )

    _DATABASE_PATH_TEMPLATE = path_template.PathTemplate(
        'projects/{project}/databases/{database}')
    _UNKNOWN_PATH_PATH_TEMPLATE = path_template.PathTemplate(
        'projects/{project}/databases/{database}/documents/{document}/{unknown_path=**}'
    )

    @classmethod
    def database_path(cls, project, database):
        """Returns a fully-qualified database resource name string."""
        return cls._DATABASE_PATH_TEMPLATE.render({
            'project': project,
            'database': database,
        })

    @classmethod
    def unknown_path_path(cls, project, database, document, unknown_path):
        """Returns a fully-qualified unknown_path resource name string."""
        return cls._UNKNOWN_PATH_PATH_TEMPLATE.render({
            'project':
            project,
            'database':
            database,
            'document':
            document,
            'unknown_path':
            unknown_path,
        })

    @classmethod
    def match_project_from_database_name(cls, database_name):
        """Parses the project from a database resource.

        Args:
          database_name (string): A fully-qualified path representing a database
            resource.

        Returns:
          A string representing the project.
        """
        return cls._DATABASE_PATH_TEMPLATE.match(database_name).get('project')

    @classmethod
    def match_database_from_database_name(cls, database_name):
        """Parses the database from a database resource.

        Args:
          database_name (string): A fully-qualified path representing a database
            resource.

        Returns:
          A string representing the database.
        """
        return cls._DATABASE_PATH_TEMPLATE.match(database_name).get('database')

    @classmethod
    def match_project_from_unknown_path_name(cls, unknown_path_name):
        """Parses the project from a unknown_path resource.

        Args:
          unknown_path_name (string): A fully-qualified path representing a unknown_path
            resource.

        Returns:
          A string representing the project.
        """
        return cls._UNKNOWN_PATH_PATH_TEMPLATE.match(unknown_path_name).get(
            'project')

    @classmethod
    def match_database_from_unknown_path_name(cls, unknown_path_name):
        """Parses the database from a unknown_path resource.

        Args:
          unknown_path_name (string): A fully-qualified path representing a unknown_path
            resource.

        Returns:
          A string representing the database.
        """
        return cls._UNKNOWN_PATH_PATH_TEMPLATE.match(unknown_path_name).get(
            'database')

    @classmethod
    def match_document_from_unknown_path_name(cls, unknown_path_name):
        """Parses the document from a unknown_path resource.

        Args:
          unknown_path_name (string): A fully-qualified path representing a unknown_path
            resource.

        Returns:
          A string representing the document.
        """
        return cls._UNKNOWN_PATH_PATH_TEMPLATE.match(unknown_path_name).get(
            'document')

    @classmethod
    def match_unknown_path_from_unknown_path_name(cls, unknown_path_name):
        """Parses the unknown_path from a unknown_path resource.

        Args:
          unknown_path_name (string): A fully-qualified path representing a unknown_path
            resource.

        Returns:
          A string representing the unknown_path.
        """
        return cls._UNKNOWN_PATH_PATH_TEMPLATE.match(unknown_path_name).get(
            'unknown_path')

    def __init__(self,
                 service_path=SERVICE_ADDRESS,
                 port=DEFAULT_SERVICE_PORT,
                 channel=None,
                 credentials=None,
                 ssl_credentials=None,
                 scopes=None,
                 client_config=None,
                 app_name=None,
                 app_version='',
                 lib_name=None,
                 lib_version='',
                 metrics_headers=()):
        """Constructor.

        Args:
          service_path (string): The domain name of the API remote host.
          port (int): The port on which to connect to the remote host.
          channel (:class:`grpc.Channel`): A ``Channel`` instance through
            which to make calls.
          credentials (object): The authorization credentials to attach to
            requests. These credentials identify this application to the
            service.
          ssl_credentials (:class:`grpc.ChannelCredentials`): A
            ``ChannelCredentials`` instance for use with an SSL-enabled
            channel.
          scopes (list[string]): A list of OAuth2 scopes to attach to requests.
          client_config (dict):
            A dictionary for call options for each method. See
            :func:`google.gax.construct_settings` for the structure of
            this data. Falls back to the default config if not specified
            or the specified config is missing data points.
          app_name (string): The name of the application calling
            the service. Recommended for analytics purposes.
          app_version (string): The version of the application calling
            the service. Recommended for analytics purposes.
          lib_name (string): The API library software used for calling
            the service. (Unless you are writing an API client itself,
            leave this as default.)
          lib_version (string): The API library software version used
            for calling the service. (Unless you are writing an API client
            itself, leave this as default.)
          metrics_headers (dict): A dictionary of values for tracking
            client library metrics. Ultimately serializes to a string
            (e.g. 'foo/1.2.3 bar/3.14.1'). This argument should be
            considered private.

        Returns:
          A FirestoreClient object.
        """
        # Unless the calling application specifically requested
        # OAuth scopes, request everything.
        if scopes is None:
            scopes = self._ALL_SCOPES

        # Initialize an empty client config, if none is set.
        if client_config is None:
            client_config = {}

        # Initialize metrics_headers as an ordered dictionary
        # (cuts down on cardinality of the resulting string slightly).
        metrics_headers = collections.OrderedDict(metrics_headers)
        metrics_headers['gl-python'] = platform.python_version()

        # The library may or may not be set, depending on what is
        # calling this client. Newer client libraries set the library name
        # and version.
        if lib_name:
            metrics_headers[lib_name] = lib_version

        # Finally, track the GAPIC package version.
        metrics_headers['gapic'] = pkg_resources.get_distribution(
            'gapic-google-cloud-firestore-v1beta1', ).version

        # Load the configuration defaults.
        default_client_config = json.loads(
            pkg_resources.resource_string(
                __name__, 'firestore_client_config.json').decode())
        defaults = api_callable.construct_settings(
            'google.firestore.v1beta1.Firestore',
            default_client_config,
            client_config,
            config.STATUS_CODE_NAMES,
            metrics_headers=metrics_headers,
            page_descriptors=self._PAGE_DESCRIPTORS, )
        self.firestore_stub = config.create_stub(
            firestore_pb2.FirestoreStub,
            channel=channel,
            service_path=service_path,
            service_port=port,
            credentials=credentials,
            scopes=scopes,
            ssl_credentials=ssl_credentials)

        self._get_document = api_callable.create_api_call(
            self.firestore_stub.GetDocument, settings=defaults['get_document'])
        self._list_documents = api_callable.create_api_call(
            self.firestore_stub.ListDocuments,
            settings=defaults['list_documents'])
        self._create_document = api_callable.create_api_call(
            self.firestore_stub.CreateDocument,
            settings=defaults['create_document'])
        self._update_document = api_callable.create_api_call(
            self.firestore_stub.UpdateDocument,
            settings=defaults['update_document'])
        self._delete_document = api_callable.create_api_call(
            self.firestore_stub.DeleteDocument,
            settings=defaults['delete_document'])
        self._batch_get_documents = api_callable.create_api_call(
            self.firestore_stub.BatchGetDocuments,
            settings=defaults['batch_get_documents'])
        self._begin_transaction = api_callable.create_api_call(
            self.firestore_stub.BeginTransaction,
            settings=defaults['begin_transaction'])
        self._commit = api_callable.create_api_call(
            self.firestore_stub.Commit, settings=defaults['commit'])
        self._rollback = api_callable.create_api_call(
            self.firestore_stub.Rollback, settings=defaults['rollback'])
        self._run_query = api_callable.create_api_call(
            self.firestore_stub.RunQuery, settings=defaults['run_query'])
        self._write = api_callable.create_api_call(
            self.firestore_stub.Write, settings=defaults['write'])
        self._listen = api_callable.create_api_call(
            self.firestore_stub.Listen, settings=defaults['listen'])
        self._list_collection_ids = api_callable.create_api_call(
            self.firestore_stub.ListCollectionIds,
            settings=defaults['list_collection_ids'])

    # Service calls
    def get_document(self,
                     name,
                     mask,
                     transaction=None,
                     read_time=None,
                     options=None):
        """
        Gets a single document.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> from google.cloud.proto.firestore.v1beta1 import common_pb2
          >>> client = firestore_client.FirestoreClient()
          >>> name = client.unknown_path_path('[PROJECT]', '[DATABASE]', '[DOCUMENT]', '[UNKNOWN_PATH]')
          >>> mask = common_pb2.DocumentMask()
          >>> response = client.get_document(name, mask)

        Args:
          name (string): The resource name of the Document to get. In the format:
            ``projects/{project_id}/databases/{database_id}/documents/{document_path}``.
          mask (:class:`google.cloud.proto.firestore.v1beta1.common_pb2.DocumentMask`): The fields to return. If not set, returns all fields.

            If the document has a field that is not present in this mask, that field
            will not be returned in the response.
          transaction (bytes): Reads the document in a transaction.
          read_time (:class:`google.protobuf.timestamp_pb2.Timestamp`): Reads the version of the document at the given time.
            This may not be older than 60 seconds.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.cloud.proto.firestore.v1beta1.document_pb2.Document` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Sanity check: We have some fields which are mutually exclusive;
        # raise ValueError if more than one is sent.
        oneof.check_oneof(
            transaction=transaction,
            read_time=read_time, )

        # Create the request object.
        request = firestore_pb2.GetDocumentRequest(
            name=name, mask=mask, transaction=transaction, read_time=read_time)
        return self._get_document(request, options)

    def list_documents(self,
                       parent,
                       collection_id,
                       order_by,
                       mask,
                       show_missing,
                       page_size=None,
                       transaction=None,
                       read_time=None,
                       options=None):
        """
        Lists documents.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> from google.cloud.proto.firestore.v1beta1 import common_pb2
          >>> from google.gax import CallOptions, INITIAL_PAGE
          >>> client = firestore_client.FirestoreClient()
          >>> parent = client.database_path('[PROJECT]', '[DATABASE]')
          >>> collection_id = ''
          >>> order_by = ''
          >>> mask = common_pb2.DocumentMask()
          >>> show_missing = False
          >>>
          >>> # Iterate over all results
          >>> for element in client.list_documents(parent, collection_id, order_by, mask, show_missing):
          >>>     # process element
          >>>     pass
          >>>
          >>> # Or iterate over results one page at a time
          >>> for page in client.list_documents(parent, collection_id, order_by, mask, show_missing, options=CallOptions(page_token=INITIAL_PAGE)):
          >>>     for element in page:
          >>>         # process element
          >>>         pass

        Args:
          parent (string): The parent resource name. In the format:
            ``projects/{project_id}/databases/{database_id}`` or
            ``projects/{project_id}/databases/{database_id}/documents/{document_path}``.
            For example:
            ``projects/my-project/databases/my-database`` or
            ``projects/my-project/databases/my-database/documents/chatrooms/my-chatroom``
          collection_id (string): The collection ID, relative to ``parent``, to list. For example: ``chatrooms``
            or ``messages``.
          order_by (string): The order to sort results by. For example: ``priority desc, name``.
          mask (:class:`google.cloud.proto.firestore.v1beta1.common_pb2.DocumentMask`): The fields to return. If not set, returns all fields.

            If a document has a field that is not present in this mask, that field
            will not be returned in the response.
          show_missing (bool): If the list should show missing documents. A missing document is a
            document that does not exist but has sub-documents. These documents will
            be returned with a key but will not have fields, ``Document.create_time``,
            or ``Document.update_time`` set.

            Requests with ``show_missing`` may not specify ``where`` or
            ``order_by``.
          page_size (int): The maximum number of resources contained in the
            underlying API response. If page streaming is performed per-
            resource, this parameter does not affect the return value. If page
            streaming is performed per-page, this determines the maximum number
            of resources in a page.
          transaction (bytes): Reads documents in a transaction.
          read_time (:class:`google.protobuf.timestamp_pb2.Timestamp`): Reads documents as they were at the given time.
            This may not be older than 60 seconds.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.gax.PageIterator` instance. By default, this
          is an iterable of :class:`google.cloud.proto.firestore.v1beta1.document_pb2.Document` instances.
          This object can also be configured to iterate over the pages
          of the response through the `CallOptions` parameter.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Sanity check: We have some fields which are mutually exclusive;
        # raise ValueError if more than one is sent.
        oneof.check_oneof(
            transaction=transaction,
            read_time=read_time, )

        # Create the request object.
        request = firestore_pb2.ListDocumentsRequest(
            parent=parent,
            collection_id=collection_id,
            order_by=order_by,
            mask=mask,
            show_missing=show_missing,
            page_size=page_size,
            transaction=transaction,
            read_time=read_time)
        return self._list_documents(request, options)

    def create_document(self,
                        parent,
                        collection_id,
                        document_id,
                        document,
                        mask,
                        options=None):
        """
        Creates a new document.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> from google.cloud.proto.firestore.v1beta1 import common_pb2
          >>> from google.cloud.proto.firestore.v1beta1 import document_pb2
          >>> client = firestore_client.FirestoreClient()
          >>> parent = client.database_path('[PROJECT]', '[DATABASE]')
          >>> collection_id = ''
          >>> document_id = ''
          >>> document = document_pb2.Document()
          >>> mask = common_pb2.DocumentMask()
          >>> response = client.create_document(parent, collection_id, document_id, document, mask)

        Args:
          parent (string): The parent resource. For example:
            ``projects/{project_id}/databases/{database_id}`` or
            ``projects/{project_id}/databases/{database_id}/documents/chatrooms/{chatroom_id}``
          collection_id (string): The collection ID, relative to ``parent``, to list. For example: ``chatrooms``.
          document_id (string): The client-assigned document ID to use for this document.

            Optional. If not specified, an ID will be assigned by the service.
          document (:class:`google.cloud.proto.firestore.v1beta1.document_pb2.Document`): The document to create. ``name`` must not be set.
          mask (:class:`google.cloud.proto.firestore.v1beta1.common_pb2.DocumentMask`): The fields to return. If not set, returns all fields.

            If the document has a field that is not present in this mask, that field
            will not be returned in the response.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.cloud.proto.firestore.v1beta1.document_pb2.Document` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_pb2.CreateDocumentRequest(
            parent=parent,
            collection_id=collection_id,
            document_id=document_id,
            document=document,
            mask=mask)
        return self._create_document(request, options)

    def update_document(self,
                        document,
                        update_mask,
                        mask,
                        current_document,
                        options=None):
        """
        Updates or inserts a document.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> from google.cloud.proto.firestore.v1beta1 import common_pb2
          >>> from google.cloud.proto.firestore.v1beta1 import document_pb2
          >>> client = firestore_client.FirestoreClient()
          >>> document = document_pb2.Document()
          >>> update_mask = common_pb2.DocumentMask()
          >>> mask = common_pb2.DocumentMask()
          >>> current_document = common_pb2.Precondition()
          >>> response = client.update_document(document, update_mask, mask, current_document)

        Args:
          document (:class:`google.cloud.proto.firestore.v1beta1.document_pb2.Document`): The updated document.
            Creates the document if it does not already exist.
          update_mask (:class:`google.cloud.proto.firestore.v1beta1.common_pb2.DocumentMask`): The fields to update.
            None of the field paths in the mask may contain a reserved name.

            If the document exists on the server and has fields not referenced in the
            mask, they are left unchanged.
            Fields referenced in the mask, but not present in the input document, are
            deleted from the document on the server.
          mask (:class:`google.cloud.proto.firestore.v1beta1.common_pb2.DocumentMask`): The fields to return. If not set, returns all fields.

            If the document has a field that is not present in this mask, that field
            will not be returned in the response.
          current_document (:class:`google.cloud.proto.firestore.v1beta1.common_pb2.Precondition`): An optional precondition on the document.
            The request will fail if this is set and not met by the target document.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.cloud.proto.firestore.v1beta1.document_pb2.Document` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_pb2.UpdateDocumentRequest(
            document=document,
            update_mask=update_mask,
            mask=mask,
            current_document=current_document)
        return self._update_document(request, options)

    def delete_document(self, name, current_document, options=None):
        """
        Deletes a document.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> from google.cloud.proto.firestore.v1beta1 import common_pb2
          >>> client = firestore_client.FirestoreClient()
          >>> name = client.unknown_path_path('[PROJECT]', '[DATABASE]', '[DOCUMENT]', '[UNKNOWN_PATH]')
          >>> current_document = common_pb2.Precondition()
          >>> client.delete_document(name, current_document)

        Args:
          name (string): The resource name of the Document to delete. In the format:
            ``projects/{project_id}/databases/{database_id}/documents/{document_path}``.
          current_document (:class:`google.cloud.proto.firestore.v1beta1.common_pb2.Precondition`): An optional precondition on the document.
            The request will fail if this is set and not met by the target document.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_pb2.DeleteDocumentRequest(
            name=name, current_document=current_document)
        self._delete_document(request, options)

    def batch_get_documents(self,
                            database,
                            documents,
                            mask,
                            transaction=None,
                            new_transaction=None,
                            read_time=None,
                            options=None):
        """
        Gets multiple documents.

        Documents returned by this method are not guaranteed to be returned in the
        same order that they were requested.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> from google.cloud.proto.firestore.v1beta1 import common_pb2
          >>> client = firestore_client.FirestoreClient()
          >>> database = client.database_path('[PROJECT]', '[DATABASE]')
          >>> documents = []
          >>> mask = common_pb2.DocumentMask()
          >>> for element in client.batch_get_documents(database, documents, mask):
          >>>     # process element
          >>>     pass

        Args:
          database (string): The database name. In the format:
            ``projects/{project_id}/databases/{database_id}``.
          documents (list[string]): The names of the documents to retrieve. In the format:
            ``projects/{project_id}/databases/{database_id}/documents/{document_path}``.
            The request will fail if any of the document is not a child resource of the
            given ``database``. Duplicate names will be elided.
          mask (:class:`google.cloud.proto.firestore.v1beta1.common_pb2.DocumentMask`): The fields to return. If not set, returns all fields.

            If a document has a field that is not present in this mask, that field will
            not be returned in the response.
          transaction (bytes): Reads documents in a transaction.
          new_transaction (:class:`google.cloud.proto.firestore.v1beta1.common_pb2.TransactionOptions`): Starts a new transaction and reads the documents.
            Defaults to a read-only transaction.
            The new transaction ID will be returned as the first response in the
            stream.
          read_time (:class:`google.protobuf.timestamp_pb2.Timestamp`): Reads documents as they were at the given time.
            This may not be older than 60 seconds.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          iterator[:class:`google.cloud.proto.firestore.v1beta1.firestore_pb2.BatchGetDocumentsResponse`].

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Sanity check: We have some fields which are mutually exclusive;
        # raise ValueError if more than one is sent.
        oneof.check_oneof(
            transaction=transaction,
            new_transaction=new_transaction,
            read_time=read_time, )

        # Create the request object.
        request = firestore_pb2.BatchGetDocumentsRequest(
            database=database,
            documents=documents,
            mask=mask,
            transaction=transaction,
            new_transaction=new_transaction,
            read_time=read_time)
        return self._batch_get_documents(request, options)

    def begin_transaction(self, database, options_, options=None):
        """
        Starts a new transaction.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> from google.cloud.proto.firestore.v1beta1 import common_pb2
          >>> client = firestore_client.FirestoreClient()
          >>> database = client.database_path('[PROJECT]', '[DATABASE]')
          >>> options_ = common_pb2.TransactionOptions()
          >>> response = client.begin_transaction(database, options_)

        Args:
          database (string): The database name. In the format:
            ``projects/{project_id}/databases/{database_id}``.
          options_ (:class:`google.cloud.proto.firestore.v1beta1.common_pb2.TransactionOptions`): The options for the transaction.
            Defaults to a read-write transaction.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.cloud.proto.firestore.v1beta1.firestore_pb2.BeginTransactionResponse` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_pb2.BeginTransactionRequest(
            database=database, options=options_)
        return self._begin_transaction(request, options)

    def commit(self, database, writes, transaction, options=None):
        """
        Commits a transaction, while optionally updating documents.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> client = firestore_client.FirestoreClient()
          >>> database = client.database_path('[PROJECT]', '[DATABASE]')
          >>> writes = []
          >>> transaction = b''
          >>> response = client.commit(database, writes, transaction)

        Args:
          database (string): The database name. In the format:
            ``projects/{project_id}/databases/{database_id}``.
          writes (list[:class:`google.cloud.proto.firestore.v1beta1.write_pb2.Write`]): The writes to apply.

            Always executed atomically and in order.
          transaction (bytes): If non-empty, applies all writes in this transaction, and commits it.
            Otherwise, applies the writes as if they were in their own transaction.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.cloud.proto.firestore.v1beta1.firestore_pb2.CommitResponse` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_pb2.CommitRequest(
            database=database, writes=writes, transaction=transaction)
        return self._commit(request, options)

    def rollback(self, database, transaction, options=None):
        """
        Rolls back a transaction.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> client = firestore_client.FirestoreClient()
          >>> database = client.database_path('[PROJECT]', '[DATABASE]')
          >>> transaction = b''
          >>> client.rollback(database, transaction)

        Args:
          database (string): The database name. In the format:
            ``projects/{project_id}/databases/{database_id}``.
          transaction (bytes): The transaction to roll back.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_pb2.RollbackRequest(
            database=database, transaction=transaction)
        self._rollback(request, options)

    def run_query(self,
                  parent,
                  structured_query,
                  transaction=None,
                  new_transaction=None,
                  read_time=None,
                  options=None):
        """
        Runs a query.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> from google.cloud.proto.firestore.v1beta1 import query_pb2
          >>> client = firestore_client.FirestoreClient()
          >>> parent = client.database_path('[PROJECT]', '[DATABASE]')
          >>> structured_query = query_pb2.StructuredQuery()
          >>> for element in client.run_query(parent, structured_query):
          >>>     # process element
          >>>     pass

        Args:
          parent (string): The parent resource name. In the format:
            ``projects/{project_id}/databases/{database_id}`` or
            ``projects/{project_id}/databases/{database_id}/documents/{document_path}``.
            For example:
            ``projects/my-project/databases/my-database`` or
            ``projects/my-project/databases/my-database/documents/chatrooms/my-chatroom``
          structured_query (:class:`google.cloud.proto.firestore.v1beta1.query_pb2.StructuredQuery`): A structured query.
          transaction (bytes): Reads documents in a transaction.
          new_transaction (:class:`google.cloud.proto.firestore.v1beta1.common_pb2.TransactionOptions`): Starts a new transaction and reads the documents.
            Defaults to a read-only transaction.
            The new transaction ID will be returned as the first response in the
            stream.
          read_time (:class:`google.protobuf.timestamp_pb2.Timestamp`): Reads documents as they were at the given time.
            This may not be older than 60 seconds.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          iterator[:class:`google.cloud.proto.firestore.v1beta1.firestore_pb2.RunQueryResponse`].

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Sanity check: We have some fields which are mutually exclusive;
        # raise ValueError if more than one is sent.
        oneof.check_oneof(
            transaction=transaction,
            new_transaction=new_transaction,
            read_time=read_time, )

        # Create the request object.
        request = firestore_pb2.RunQueryRequest(
            parent=parent,
            structured_query=structured_query,
            transaction=transaction,
            new_transaction=new_transaction,
            read_time=read_time)
        return self._run_query(request, options)

    def write(self, requests, options=None):
        """
        Streams batches of document updates and deletes, in order.

        EXPERIMENTAL: This method interface might change in the future.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> from google.cloud.proto.firestore.v1beta1 import firestore_pb2
          >>> client = firestore_client.FirestoreClient()
          >>> database = client.database_path('[PROJECT]', '[DATABASE]')
          >>> stream_id = ''
          >>> writes = []
          >>> stream_token = b''
          >>> request = firestore_pb2.WriteRequest(database, stream_id, writes, stream_token)
          >>> requests = [request]
          >>> for element in client.write(requests):
          >>>     # process element
          >>>     pass

        Args:
          requests (iterator[:class:`google.cloud.proto.firestore.v1beta1.firestore_pb2.WriteRequest`]): The input objects.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          iterator[:class:`google.cloud.proto.firestore.v1beta1.firestore_pb2.WriteResponse`].

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        return self._write(requests, options)

    def listen(self, requests, options=None):
        """
        Listens to changes.

        EXPERIMENTAL: This method interface might change in the future.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> from google.cloud.proto.firestore.v1beta1 import firestore_pb2
          >>> client = firestore_client.FirestoreClient()
          >>> database = client.database_path('[PROJECT]', '[DATABASE]')
          >>> request = firestore_pb2.ListenRequest(database)
          >>> requests = [request]
          >>> for element in client.listen(requests):
          >>>     # process element
          >>>     pass

        Args:
          requests (iterator[:class:`google.cloud.proto.firestore.v1beta1.firestore_pb2.ListenRequest`]): The input objects.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          iterator[:class:`google.cloud.proto.firestore.v1beta1.firestore_pb2.ListenResponse`].

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        return self._listen(requests, options)

    def list_collection_ids(self, parent, page_size=None, options=None):
        """
        Lists all the collection IDs underneath a document.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_client
          >>> from google.gax import CallOptions, INITIAL_PAGE
          >>> client = firestore_client.FirestoreClient()
          >>> parent = client.unknown_path_path('[PROJECT]', '[DATABASE]', '[DOCUMENT]', '[UNKNOWN_PATH]')
          >>>
          >>> # Iterate over all results
          >>> for element in client.list_collection_ids(parent):
          >>>     # process element
          >>>     pass
          >>>
          >>> # Or iterate over results one page at a time
          >>> for page in client.list_collection_ids(parent, options=CallOptions(page_token=INITIAL_PAGE)):
          >>>     for element in page:
          >>>         # process element
          >>>         pass

        Args:
          parent (string): The parent document. In the format:
            ``projects/{project_id}/databases/{database_id}/documents/{document_path}``.
            For example:
            ``projects/my-project/databases/my-database/documents/chatrooms/my-chatroom``
          page_size (int): The maximum number of resources contained in the
            underlying API response. If page streaming is performed per-
            resource, this parameter does not affect the return value. If page
            streaming is performed per-page, this determines the maximum number
            of resources in a page.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.gax.PageIterator` instance. By default, this
          is an iterable of string instances.
          This object can also be configured to iterate over the pages
          of the response through the `CallOptions` parameter.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_pb2.ListCollectionIdsRequest(
            parent=parent, page_size=page_size)
        return self._list_collection_ids(request, options)
