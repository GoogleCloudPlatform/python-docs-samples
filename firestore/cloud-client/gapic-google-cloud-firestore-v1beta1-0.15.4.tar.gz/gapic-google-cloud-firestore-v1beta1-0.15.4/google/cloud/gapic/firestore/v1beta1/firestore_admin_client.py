# Copyright 2017, Google Inc. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# EDITING INSTRUCTIONS
# This file was generated from the file
# https://github.com/google/googleapis/blob/master/google/firestore/v1beta1/firestore_admin.proto,
# and updates to that file get reflected here through a refresh process.
# For the short term, the refresh process will only be runnable by Google engineers.
#
# The only allowed edits are to method and file documentation. A 3-way
# merge preserves those additions if the generated source changes.
"""Accesses the google.firestore.v1beta1 FirestoreAdmin API."""

import collections
import json
import os
import pkg_resources
import platform

from google.gax import api_callable
from google.gax import config
from google.gax import path_template
import google.gax

from google.cloud.gapic.firestore.v1beta1 import enums
from google.cloud.proto.firestore.v1beta1 import firestore_admin_pb2
from google.cloud.proto.firestore.v1beta1 import index_pb2

_PageDesc = google.gax.PageDescriptor


class FirestoreAdminClient(object):
    """
    The Cloud Firestore Admin API.

    This API provides several administrative services for Cloud Firestore.

    # Concepts

    Project, Database, Namespace, Collection, and Document are used as defined in
    the Google Cloud Firestore API.

    Operation: An Operation represents work being performed in the background.


    # Services

    ## Index

    The index service manages Cloud Firestore indexes.

    Index enabling and disabling are performed asynchronously.
    An Operation resource is created for each such asynchronous operation.
    The state of the operation (including any errors encountered)
    may be queried via the Operation resource.

    ## Metadata

    Provides metadata and statistical information about data in Cloud Firestore.
    The data provided as part of this API may be stale.

    ## Operation

    The Operations collection provides a record of actions performed for the
    specified Project (including any Operations in progress). Operations are not
    created directly but through calls on other collections or resources.

    An Operation that is not yet done may be cancelled. The request to cancel is
    asynchronous and the Operation may continue to run for some time after the
    request to cancel is made.

    An Operation that is done may be deleted so that it is no longer listed as
    part of the Operation collection.

    Operations are created by service ``FirestoreAdmin``, but are accessed via
    service ``google.longrunning.Operations``.
    """

    SERVICE_ADDRESS = 'firestore.googleapis.com'
    """The default address of the service."""

    DEFAULT_SERVICE_PORT = 443
    """The default port of the service."""

    _PAGE_DESCRIPTORS = {
        'list_indexes':
        _PageDesc('page_token', 'next_page_token', 'indexes'),
        'list_databases':
        _PageDesc('page_token', 'next_page_token', 'databases'),
        'list_namespaces':
        _PageDesc('page_token', 'next_page_token', 'namespaces'),
        'list_collection_groups':
        _PageDesc('page_token', 'next_page_token', 'collection_groups'),
        'list_fields':
        _PageDesc('page_token', 'next_page_token', 'fields')
    }

    # The scopes needed to make gRPC calls to all of the methods defined in
    # this service
    _ALL_SCOPES = ('https://www.googleapis.com/auth/cloud-platform',
                   'https://www.googleapis.com/auth/datastore', )

    _PROJECT_PATH_TEMPLATE = path_template.PathTemplate('projects/{project}')
    _DATABASE_PATH_TEMPLATE = path_template.PathTemplate(
        'projects/{project}/databases/{database}')
    _COLLECTION_GROUP_PATH_TEMPLATE = path_template.PathTemplate(
        'projects/{project}/databases/{database}/collectionGroups/{collection_group}'
    )
    _FIELD_PATH_TEMPLATE = path_template.PathTemplate(
        'projects/{project}/databases/{database}/collectionGroups/{collection_group}/fields/{field}'
    )
    _INDEXE_PATH_TEMPLATE = path_template.PathTemplate(
        'projects/{project}/databases/{database}/indexes/{indexe}')
    _NAMESPACE_PATH_TEMPLATE = path_template.PathTemplate(
        'projects/{project}/databases/{database}/namespaces/{namespace}')

    @classmethod
    def project_path(cls, project):
        """Returns a fully-qualified project resource name string."""
        return cls._PROJECT_PATH_TEMPLATE.render({
            'project': project,
        })

    @classmethod
    def database_path(cls, project, database):
        """Returns a fully-qualified database resource name string."""
        return cls._DATABASE_PATH_TEMPLATE.render({
            'project': project,
            'database': database,
        })

    @classmethod
    def collection_group_path(cls, project, database, collection_group):
        """Returns a fully-qualified collection_group resource name string."""
        return cls._COLLECTION_GROUP_PATH_TEMPLATE.render({
            'project':
            project,
            'database':
            database,
            'collection_group':
            collection_group,
        })

    @classmethod
    def field_path(cls, project, database, collection_group, field):
        """Returns a fully-qualified field resource name string."""
        return cls._FIELD_PATH_TEMPLATE.render({
            'project':
            project,
            'database':
            database,
            'collection_group':
            collection_group,
            'field':
            field,
        })

    @classmethod
    def indexe_path(cls, project, database, indexe):
        """Returns a fully-qualified indexe resource name string."""
        return cls._INDEXE_PATH_TEMPLATE.render({
            'project': project,
            'database': database,
            'indexe': indexe,
        })

    @classmethod
    def namespace_path(cls, project, database, namespace):
        """Returns a fully-qualified namespace resource name string."""
        return cls._NAMESPACE_PATH_TEMPLATE.render({
            'project': project,
            'database': database,
            'namespace': namespace,
        })

    @classmethod
    def match_project_from_project_name(cls, project_name):
        """Parses the project from a project resource.

        Args:
          project_name (string): A fully-qualified path representing a project
            resource.

        Returns:
          A string representing the project.
        """
        return cls._PROJECT_PATH_TEMPLATE.match(project_name).get('project')

    @classmethod
    def match_project_from_database_name(cls, database_name):
        """Parses the project from a database resource.

        Args:
          database_name (string): A fully-qualified path representing a database
            resource.

        Returns:
          A string representing the project.
        """
        return cls._DATABASE_PATH_TEMPLATE.match(database_name).get('project')

    @classmethod
    def match_database_from_database_name(cls, database_name):
        """Parses the database from a database resource.

        Args:
          database_name (string): A fully-qualified path representing a database
            resource.

        Returns:
          A string representing the database.
        """
        return cls._DATABASE_PATH_TEMPLATE.match(database_name).get('database')

    @classmethod
    def match_project_from_collection_group_name(cls, collection_group_name):
        """Parses the project from a collection_group resource.

        Args:
          collection_group_name (string): A fully-qualified path representing a collection_group
            resource.

        Returns:
          A string representing the project.
        """
        return cls._COLLECTION_GROUP_PATH_TEMPLATE.match(
            collection_group_name).get('project')

    @classmethod
    def match_database_from_collection_group_name(cls, collection_group_name):
        """Parses the database from a collection_group resource.

        Args:
          collection_group_name (string): A fully-qualified path representing a collection_group
            resource.

        Returns:
          A string representing the database.
        """
        return cls._COLLECTION_GROUP_PATH_TEMPLATE.match(
            collection_group_name).get('database')

    @classmethod
    def match_collection_group_from_collection_group_name(
            cls, collection_group_name):
        """Parses the collection_group from a collection_group resource.

        Args:
          collection_group_name (string): A fully-qualified path representing a collection_group
            resource.

        Returns:
          A string representing the collection_group.
        """
        return cls._COLLECTION_GROUP_PATH_TEMPLATE.match(
            collection_group_name).get('collection_group')

    @classmethod
    def match_project_from_field_name(cls, field_name):
        """Parses the project from a field resource.

        Args:
          field_name (string): A fully-qualified path representing a field
            resource.

        Returns:
          A string representing the project.
        """
        return cls._FIELD_PATH_TEMPLATE.match(field_name).get('project')

    @classmethod
    def match_database_from_field_name(cls, field_name):
        """Parses the database from a field resource.

        Args:
          field_name (string): A fully-qualified path representing a field
            resource.

        Returns:
          A string representing the database.
        """
        return cls._FIELD_PATH_TEMPLATE.match(field_name).get('database')

    @classmethod
    def match_collection_group_from_field_name(cls, field_name):
        """Parses the collection_group from a field resource.

        Args:
          field_name (string): A fully-qualified path representing a field
            resource.

        Returns:
          A string representing the collection_group.
        """
        return cls._FIELD_PATH_TEMPLATE.match(field_name).get(
            'collection_group')

    @classmethod
    def match_field_from_field_name(cls, field_name):
        """Parses the field from a field resource.

        Args:
          field_name (string): A fully-qualified path representing a field
            resource.

        Returns:
          A string representing the field.
        """
        return cls._FIELD_PATH_TEMPLATE.match(field_name).get('field')

    @classmethod
    def match_project_from_indexe_name(cls, indexe_name):
        """Parses the project from a indexe resource.

        Args:
          indexe_name (string): A fully-qualified path representing a indexe
            resource.

        Returns:
          A string representing the project.
        """
        return cls._INDEXE_PATH_TEMPLATE.match(indexe_name).get('project')

    @classmethod
    def match_database_from_indexe_name(cls, indexe_name):
        """Parses the database from a indexe resource.

        Args:
          indexe_name (string): A fully-qualified path representing a indexe
            resource.

        Returns:
          A string representing the database.
        """
        return cls._INDEXE_PATH_TEMPLATE.match(indexe_name).get('database')

    @classmethod
    def match_indexe_from_indexe_name(cls, indexe_name):
        """Parses the indexe from a indexe resource.

        Args:
          indexe_name (string): A fully-qualified path representing a indexe
            resource.

        Returns:
          A string representing the indexe.
        """
        return cls._INDEXE_PATH_TEMPLATE.match(indexe_name).get('indexe')

    @classmethod
    def match_project_from_namespace_name(cls, namespace_name):
        """Parses the project from a namespace resource.

        Args:
          namespace_name (string): A fully-qualified path representing a namespace
            resource.

        Returns:
          A string representing the project.
        """
        return cls._NAMESPACE_PATH_TEMPLATE.match(namespace_name).get(
            'project')

    @classmethod
    def match_database_from_namespace_name(cls, namespace_name):
        """Parses the database from a namespace resource.

        Args:
          namespace_name (string): A fully-qualified path representing a namespace
            resource.

        Returns:
          A string representing the database.
        """
        return cls._NAMESPACE_PATH_TEMPLATE.match(namespace_name).get(
            'database')

    @classmethod
    def match_namespace_from_namespace_name(cls, namespace_name):
        """Parses the namespace from a namespace resource.

        Args:
          namespace_name (string): A fully-qualified path representing a namespace
            resource.

        Returns:
          A string representing the namespace.
        """
        return cls._NAMESPACE_PATH_TEMPLATE.match(namespace_name).get(
            'namespace')

    def __init__(self,
                 service_path=SERVICE_ADDRESS,
                 port=DEFAULT_SERVICE_PORT,
                 channel=None,
                 credentials=None,
                 ssl_credentials=None,
                 scopes=None,
                 client_config=None,
                 app_name=None,
                 app_version='',
                 lib_name=None,
                 lib_version='',
                 metrics_headers=()):
        """Constructor.

        Args:
          service_path (string): The domain name of the API remote host.
          port (int): The port on which to connect to the remote host.
          channel (:class:`grpc.Channel`): A ``Channel`` instance through
            which to make calls.
          credentials (object): The authorization credentials to attach to
            requests. These credentials identify this application to the
            service.
          ssl_credentials (:class:`grpc.ChannelCredentials`): A
            ``ChannelCredentials`` instance for use with an SSL-enabled
            channel.
          scopes (list[string]): A list of OAuth2 scopes to attach to requests.
          client_config (dict):
            A dictionary for call options for each method. See
            :func:`google.gax.construct_settings` for the structure of
            this data. Falls back to the default config if not specified
            or the specified config is missing data points.
          app_name (string): The name of the application calling
            the service. Recommended for analytics purposes.
          app_version (string): The version of the application calling
            the service. Recommended for analytics purposes.
          lib_name (string): The API library software used for calling
            the service. (Unless you are writing an API client itself,
            leave this as default.)
          lib_version (string): The API library software version used
            for calling the service. (Unless you are writing an API client
            itself, leave this as default.)
          metrics_headers (dict): A dictionary of values for tracking
            client library metrics. Ultimately serializes to a string
            (e.g. 'foo/1.2.3 bar/3.14.1'). This argument should be
            considered private.

        Returns:
          A FirestoreAdminClient object.
        """
        # Unless the calling application specifically requested
        # OAuth scopes, request everything.
        if scopes is None:
            scopes = self._ALL_SCOPES

        # Initialize an empty client config, if none is set.
        if client_config is None:
            client_config = {}

        # Initialize metrics_headers as an ordered dictionary
        # (cuts down on cardinality of the resulting string slightly).
        metrics_headers = collections.OrderedDict(metrics_headers)
        metrics_headers['gl-python'] = platform.python_version()

        # The library may or may not be set, depending on what is
        # calling this client. Newer client libraries set the library name
        # and version.
        if lib_name:
            metrics_headers[lib_name] = lib_version

        # Finally, track the GAPIC package version.
        metrics_headers['gapic'] = pkg_resources.get_distribution(
            'gapic-google-cloud-firestore-v1beta1', ).version

        # Load the configuration defaults.
        default_client_config = json.loads(
            pkg_resources.resource_string(
                __name__, 'firestore_admin_client_config.json').decode())
        defaults = api_callable.construct_settings(
            'google.firestore.v1beta1.FirestoreAdmin',
            default_client_config,
            client_config,
            config.STATUS_CODE_NAMES,
            metrics_headers=metrics_headers,
            page_descriptors=self._PAGE_DESCRIPTORS, )
        self.firestore_admin_stub = config.create_stub(
            firestore_admin_pb2.FirestoreAdminStub,
            channel=channel,
            service_path=service_path,
            service_port=port,
            credentials=credentials,
            scopes=scopes,
            ssl_credentials=ssl_credentials)

        self._create_index = api_callable.create_api_call(
            self.firestore_admin_stub.CreateIndex,
            settings=defaults['create_index'])
        self._list_indexes = api_callable.create_api_call(
            self.firestore_admin_stub.ListIndexes,
            settings=defaults['list_indexes'])
        self._get_index = api_callable.create_api_call(
            self.firestore_admin_stub.GetIndex, settings=defaults['get_index'])
        self._delete_index = api_callable.create_api_call(
            self.firestore_admin_stub.DeleteIndex,
            settings=defaults['delete_index'])
        self._enable_index = api_callable.create_api_call(
            self.firestore_admin_stub.EnableIndex,
            settings=defaults['enable_index'])
        self._disable_index = api_callable.create_api_call(
            self.firestore_admin_stub.DisableIndex,
            settings=defaults['disable_index'])
        self._list_databases = api_callable.create_api_call(
            self.firestore_admin_stub.ListDatabases,
            settings=defaults['list_databases'])
        self._get_database = api_callable.create_api_call(
            self.firestore_admin_stub.GetDatabase,
            settings=defaults['get_database'])
        self._list_namespaces = api_callable.create_api_call(
            self.firestore_admin_stub.ListNamespaces,
            settings=defaults['list_namespaces'])
        self._get_namespace = api_callable.create_api_call(
            self.firestore_admin_stub.GetNamespace,
            settings=defaults['get_namespace'])
        self._list_collection_groups = api_callable.create_api_call(
            self.firestore_admin_stub.ListCollectionGroups,
            settings=defaults['list_collection_groups'])
        self._get_collection_group = api_callable.create_api_call(
            self.firestore_admin_stub.GetCollectionGroup,
            settings=defaults['get_collection_group'])
        self._list_fields = api_callable.create_api_call(
            self.firestore_admin_stub.ListFields,
            settings=defaults['list_fields'])
        self._get_field = api_callable.create_api_call(
            self.firestore_admin_stub.GetField, settings=defaults['get_field'])

    # Service calls
    def create_index(self, parent, index, options=None):
        """
        Creates the specified index.
        A newly created index's initial state is ``ENABLING``. On completion of the
        returned ``google.longrunning.Operation``, the state will be ``ENABLED``.
        If the index already exists, the call will return an ``ALREADY_EXISTS``
        status.

        Indexes with a single field cannot be created.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> from google.cloud.proto.firestore.v1beta1 import index_pb2
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> parent = client.database_path('[PROJECT]', '[DATABASE]')
          >>> index = index_pb2.Index()
          >>> response = client.create_index(parent, index)

        Args:
          parent (string): The name of the database this index will apply to. For example:
            ``projects/{project_id}/databases/{database_id}``
          index (:class:`google.cloud.proto.firestore.v1beta1.index_pb2.Index`): The index to create. The name and state should not be specified.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.longrunning.operations_pb2.Operation` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.CreateIndexRequest(
            parent=parent, index=index)
        return self._create_index(request, options)

    def list_indexes(self, parent, filter_, page_size=None, options=None):
        """
        Lists the indexes that match the specified filters.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> from google.gax import CallOptions, INITIAL_PAGE
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> parent = client.database_path('[PROJECT]', '[DATABASE]')
          >>> filter_ = ''
          >>>
          >>> # Iterate over all results
          >>> for element in client.list_indexes(parent, filter_):
          >>>     # process element
          >>>     pass
          >>>
          >>> # Or iterate over results one page at a time
          >>> for page in client.list_indexes(parent, filter_, options=CallOptions(page_token=INITIAL_PAGE)):
          >>>     for element in page:
          >>>         # process element
          >>>         pass

        Args:
          parent (string): The database name. For example:
            ``projects/{project_id}/databases/{database_id}``
          filter_ (string)
          page_size (int): The maximum number of resources contained in the
            underlying API response. If page streaming is performed per-
            resource, this parameter does not affect the return value. If page
            streaming is performed per-page, this determines the maximum number
            of resources in a page.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.gax.PageIterator` instance. By default, this
          is an iterable of :class:`google.cloud.proto.firestore.v1beta1.index_pb2.Index` instances.
          This object can also be configured to iterate over the pages
          of the response through the `CallOptions` parameter.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.ListIndexesRequest(
            parent=parent, filter=filter_, page_size=page_size)
        return self._list_indexes(request, options)

    def get_index(self, name, options=None):
        """
        Gets an index.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> name = client.indexe_path('[PROJECT]', '[DATABASE]', '[INDEXE]')
          >>> response = client.get_index(name)

        Args:
          name (string): The name of the index. For example:
            ``projects/{project_id}/databases/{database_id}/indexes/{index_id}``
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.cloud.proto.firestore.v1beta1.index_pb2.Index` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.GetIndexRequest(name=name)
        return self._get_index(request, options)

    def delete_index(self, name, options=None):
        """
        Deletes an index.
        An index can be deleted only when it is in the ``DISABLED`` state.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> name = client.indexe_path('[PROJECT]', '[DATABASE]', '[INDEXE]')
          >>> client.delete_index(name)

        Args:
          name (string): The index name. For example:
            ``projects/{project_id}/databases/{database_id}/indexes/{index_id}``
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.DeleteIndexRequest(name=name)
        self._delete_index(request, options)

    def enable_index(self, name, options=None):
        """
        If successful, the result operation's field response is of type
        ``FirestoreAdmin.Index``.
        The result operation's field metadata will be type
        ``FirestoreAdmin.IndexOperationMetadata``.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> name = client.indexe_path('[PROJECT]', '[DATABASE]', '[INDEXE]')
          >>> response = client.enable_index(name)

        Args:
          name (string): The index name. For example:
            ``projects/{project_id}/databases/{database_id}/indexes/{index_id}``
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.longrunning.operations_pb2.Operation` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.EnableIndexRequest(name=name)
        return self._enable_index(request, options)

    def disable_index(self, name, options=None):
        """
        If successful, the result operation's field response is of type
        ``FirestoreAdmin.Index``.
        The result operation's field metadata will be type
        ``FirestoreAdmin.IndexOperationMetadata``.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> name = client.indexe_path('[PROJECT]', '[DATABASE]', '[INDEXE]')
          >>> response = client.disable_index(name)

        Args:
          name (string): The index name. For example:
            ``projects/{project_id}/databases/{database_id}/indexes/{index_id}``
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.longrunning.operations_pb2.Operation` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.DisableIndexRequest(name=name)
        return self._disable_index(request, options)

    def list_databases(self, parent, page_size=None, options=None):
        """
        Lists information about the databases of a project.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> from google.gax import CallOptions, INITIAL_PAGE
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> parent = client.project_path('[PROJECT]')
          >>>
          >>> # Iterate over all results
          >>> for element in client.list_databases(parent):
          >>>     # process element
          >>>     pass
          >>>
          >>> # Or iterate over results one page at a time
          >>> for page in client.list_databases(parent, options=CallOptions(page_token=INITIAL_PAGE)):
          >>>     for element in page:
          >>>         # process element
          >>>         pass

        Args:
          parent (string): The project resource name. For example:
            ``projects/{project_id}``
          page_size (int): The maximum number of resources contained in the
            underlying API response. If page streaming is performed per-
            resource, this parameter does not affect the return value. If page
            streaming is performed per-page, this determines the maximum number
            of resources in a page.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.gax.PageIterator` instance. By default, this
          is an iterable of :class:`google.cloud.proto.firestore.v1beta1.firestore_admin_pb2.Database` instances.
          This object can also be configured to iterate over the pages
          of the response through the `CallOptions` parameter.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.ListDatabasesRequest(
            parent=parent, page_size=page_size)
        return self._list_databases(request, options)

    def get_database(self, name, options=None):
        """
        Gets information about a database.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> name = client.database_path('[PROJECT]', '[DATABASE]')
          >>> response = client.get_database(name)

        Args:
          name (string): The database resource name. For example:
            ``projects/{project_id}/databases/{database_id}``
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.cloud.proto.firestore.v1beta1.firestore_admin_pb2.Database` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.GetDatabaseRequest(name=name)
        return self._get_database(request, options)

    def list_namespaces(self, parent, page_size=None, options=None):
        """
        Lists information about the namespaces of a database.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> from google.gax import CallOptions, INITIAL_PAGE
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> parent = client.database_path('[PROJECT]', '[DATABASE]')
          >>>
          >>> # Iterate over all results
          >>> for element in client.list_namespaces(parent):
          >>>     # process element
          >>>     pass
          >>>
          >>> # Or iterate over results one page at a time
          >>> for page in client.list_namespaces(parent, options=CallOptions(page_token=INITIAL_PAGE)):
          >>>     for element in page:
          >>>         # process element
          >>>         pass

        Args:
          parent (string): The database resource name. For example:
            ``projects/{project_id}/databases/{database_id}``
          page_size (int): The maximum number of resources contained in the
            underlying API response. If page streaming is performed per-
            resource, this parameter does not affect the return value. If page
            streaming is performed per-page, this determines the maximum number
            of resources in a page.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.gax.PageIterator` instance. By default, this
          is an iterable of :class:`google.cloud.proto.firestore.v1beta1.firestore_admin_pb2.Namespace` instances.
          This object can also be configured to iterate over the pages
          of the response through the `CallOptions` parameter.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.ListNamespacesRequest(
            parent=parent, page_size=page_size)
        return self._list_namespaces(request, options)

    def get_namespace(self, name, options=None):
        """
        Gets information about a namespace.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> name = client.namespace_path('[PROJECT]', '[DATABASE]', '[NAMESPACE]')
          >>> response = client.get_namespace(name)

        Args:
          name (string): The namespace resource name. For example:
            ``projects/{project_id}/databases/{database_id}/namespaces/{namespace_id}``
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.cloud.proto.firestore.v1beta1.firestore_admin_pb2.Namespace` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.GetNamespaceRequest(name=name)
        return self._get_namespace(request, options)

    def list_collection_groups(self, parent, page_size=None, options=None):
        """
        Lists information about the collection groups of a database.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> from google.gax import CallOptions, INITIAL_PAGE
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> parent = client.database_path('[PROJECT]', '[DATABASE]')
          >>>
          >>> # Iterate over all results
          >>> for element in client.list_collection_groups(parent):
          >>>     # process element
          >>>     pass
          >>>
          >>> # Or iterate over results one page at a time
          >>> for page in client.list_collection_groups(parent, options=CallOptions(page_token=INITIAL_PAGE)):
          >>>     for element in page:
          >>>         # process element
          >>>         pass

        Args:
          parent (string): The database resource name. For example:
            ``projects/{project_id}/databases/{database_id}``
          page_size (int): The maximum number of resources contained in the
            underlying API response. If page streaming is performed per-
            resource, this parameter does not affect the return value. If page
            streaming is performed per-page, this determines the maximum number
            of resources in a page.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.gax.PageIterator` instance. By default, this
          is an iterable of :class:`google.cloud.proto.firestore.v1beta1.firestore_admin_pb2.CollectionGroup` instances.
          This object can also be configured to iterate over the pages
          of the response through the `CallOptions` parameter.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.ListCollectionGroupsRequest(
            parent=parent, page_size=page_size)
        return self._list_collection_groups(request, options)

    def get_collection_group(self, name, options=None):
        """
        Gets information about a collection group.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> name = client.collection_group_path('[PROJECT]', '[DATABASE]', '[COLLECTION_GROUP]')
          >>> response = client.get_collection_group(name)

        Args:
          name (string): The collection group resource name. For example:
            ``projects/{project_id}/databases/{database_id}/collectionGroup/{collection_id}``
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.cloud.proto.firestore.v1beta1.firestore_admin_pb2.CollectionGroup` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.GetCollectionGroupRequest(name=name)
        return self._get_collection_group(request, options)

    def list_fields(self, parent, page_size=None, options=None):
        """
        Lists information about the fields of a collection group.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> from google.gax import CallOptions, INITIAL_PAGE
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> parent = client.collection_group_path('[PROJECT]', '[DATABASE]', '[COLLECTION_GROUP]')
          >>>
          >>> # Iterate over all results
          >>> for element in client.list_fields(parent):
          >>>     # process element
          >>>     pass
          >>>
          >>> # Or iterate over results one page at a time
          >>> for page in client.list_fields(parent, options=CallOptions(page_token=INITIAL_PAGE)):
          >>>     for element in page:
          >>>         # process element
          >>>         pass

        Args:
          parent (string): The collection group resource name. For example:
            ``projects/{project_id}/databases/{database_id}/collectionGroup/{collection_id}``
          page_size (int): The maximum number of resources contained in the
            underlying API response. If page streaming is performed per-
            resource, this parameter does not affect the return value. If page
            streaming is performed per-page, this determines the maximum number
            of resources in a page.
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.gax.PageIterator` instance. By default, this
          is an iterable of :class:`google.cloud.proto.firestore.v1beta1.firestore_admin_pb2.Field` instances.
          This object can also be configured to iterate over the pages
          of the response through the `CallOptions` parameter.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.ListFieldsRequest(
            parent=parent, page_size=page_size)
        return self._list_fields(request, options)

    def get_field(self, name, options=None):
        """
        Gets information about a field.

        Example:
          >>> from google.cloud.gapic.firestore.v1beta1 import firestore_admin_client
          >>> client = firestore_admin_client.FirestoreAdminClient()
          >>> name = client.field_path('[PROJECT]', '[DATABASE]', '[COLLECTION_GROUP]', '[FIELD]')
          >>> response = client.get_field(name)

        Args:
          name (string): The field resource name. For example:
            ``projects/{project_id}/databases/{database_id}/collectionGroups/{collection_id}/fields/{field_id}``
          options (:class:`google.gax.CallOptions`): Overrides the default
            settings for this call, e.g, timeout, retries etc.

        Returns:
          A :class:`google.cloud.proto.firestore.v1beta1.firestore_admin_pb2.Field` instance.

        Raises:
          :exc:`google.gax.errors.GaxError` if the RPC is aborted.
          :exc:`ValueError` if the parameters are invalid.
        """
        # Create the request object.
        request = firestore_admin_pb2.GetFieldRequest(name=name)
        return self._get_field(request, options)
