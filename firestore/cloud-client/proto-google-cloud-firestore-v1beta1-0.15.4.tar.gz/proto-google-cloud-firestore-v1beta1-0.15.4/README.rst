gRPC library for Google Cloud Firestore API

proto-google-cloud-firestore-v1beta1 is the IDL-derived library for the firestore (v1beta1) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/firestore/v1beta1
